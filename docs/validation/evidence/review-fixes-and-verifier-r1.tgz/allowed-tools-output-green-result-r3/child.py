import os,sys,pathlib
source=pathlib.Path(os.environ['FOCUSED_SOURCE']).resolve()
import sglang
assert pathlib.Path(sglang.__file__).resolve().is_relative_to(source/'python')
from sglang.test.test_utils import maybe_stub_sgl_kernel
maybe_stub_sgl_kernel()
import pytest
raise SystemExit(pytest.main(sys.argv[1:]))
